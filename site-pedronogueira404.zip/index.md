---
layout: default
title: Início
---

# Bem-vindo

Este é o site pessoal de Pedro Nogueira.

Acesse o [blog](/blog/) ou saiba mais [sobre mim](/sobre/).
